library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity contador10 is
    port(
        clock  : in  STD_LOGIC;
        reset  : in  STD_LOGIC;
        enable : in  STD_LOGIC;
        rci    : in  STD_LOGIC;
        load   : in  STD_LOGIC;
        D      : in  STD_LOGIC_VECTOR(3 downto 0);

        Q       : out STD_LOGIC_VECTOR(3 downto 0);
        rco     : out STD_LOGIC
    );
end contador10;

architecture contador10_arch of contador10 is

    type estado_tipo is (
        E0,E1,E2,E3,E4,E5,E6,E7,E8,E9
    );

    signal estado : estado_tipo := E0;

begin

    ------------------------------------------------------------------
    -- M�quina de estados
    ------------------------------------------------------------------

    process(clock)
    begin

        if rising_edge(clock) then

            ----------------------------------------------------------
            -- Reset s�ncrono (maior prioridade)
            ----------------------------------------------------------

            if reset = '1' then

                estado <= E0;

            ----------------------------------------------------------
            -- Load s�ncrono
            ----------------------------------------------------------

            elsif load = '1' then

                case D is

                    when "0000" => estado <= E0;
                    when "0001" => estado <= E1;
                    when "0010" => estado <= E2;
                    when "0011" => estado <= E3;
                    when "0100" => estado <= E4;
                    when "0101" => estado <= E5;
                    when "0110" => estado <= E6;
                    when "0111" => estado <= E7;
                    when "1000" => estado <= E8;
                    when "1001" => estado <= E9;

                    when others => estado <= E0;

                end case;

            ----------------------------------------------------------
            -- Contagem
            ----------------------------------------------------------

            elsif (enable = '0' and rci = '0') then

                case estado is

                    when E0 => estado <= E1;
                    when E1 => estado <= E2;
                    when E2 => estado <= E3;
                    when E3 => estado <= E4;
                    when E4 => estado <= E5;
                    when E5 => estado <= E6;
                    when E6 => estado <= E7;
                    when E7 => estado <= E8;
                    when E8 => estado <= E9;
                    when E9 => estado <= E0;

                end case;

            end if;

        end if;

    end process;

    ------------------------------------------------------------------
    -- Sa�da Moore
    ------------------------------------------------------------------

    with estado select
    Q <=
        "0000" when E0,
        "0001" when E1,
        "0010" when E2,
        "0011" when E3,
        "0100" when E4,
        "0101" when E5,
        "0110" when E6,
        "0111" when E7,
        "1000" when E8,
        "1001" when E9;

    ------------------------------------------------------------------
    -- Ripple Carry Out (ativo em n�vel baixo)
    ------------------------------------------------------------------

    rco <= '0' when estado = E9 else '1';

end contador10_arch;
