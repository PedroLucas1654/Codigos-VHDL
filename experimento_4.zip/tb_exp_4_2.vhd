library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_q2 is
end tb_q2;

architecture Behavioral of tb_q2 is

    component q2
        Port (
            A, B, C, D, E, F, G : in STD_LOGIC;
            S : out STD_LOGIC
        );
    end component;

    signal A_tb, B_tb, C_tb, D_tb : STD_LOGIC;
    signal E_tb, F_tb, G_tb       : STD_LOGIC;
    signal S_tb                   : STD_LOGIC;

    signal entrada : STD_LOGIC_VECTOR(6 downto 0);

begin

    uut: q2
        port map (
            A => A_tb,
            B => B_tb,
            C => C_tb,
            D => D_tb,
            E => E_tb,
            F => F_tb,
            G => G_tb,
            S => S_tb
        );

    process
    begin
        for i in 0 to 127 loop
            
            entrada <= std_logic_vector(to_unsigned(i, 7));

            A_tb <= entrada(6);
            B_tb <= entrada(5);
            C_tb <= entrada(4);
            D_tb <= entrada(3);
            E_tb <= entrada(2);
            F_tb <= entrada(1);
            G_tb <= entrada(0);

            wait for 10 ns;

        end loop;

        wait;
    end process;

end Behavioral;
