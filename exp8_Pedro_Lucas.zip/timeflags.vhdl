library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity timeflags is
    Port (
        dezena  : in  STD_LOGIC_VECTOR(3 downto 0);
        unidade : in  STD_LOGIC_VECTOR(3 downto 0);

        T5  : out STD_LOGIC;
        T6  : out STD_LOGIC;
        T20 : out STD_LOGIC;
        T60 : out STD_LOGIC
    );
end timeflags;

architecture Behavioral of timeflags is

begin

    -- 05
    T5 <= '1' when (dezena = "0000" and unidade = "0101")
          else '0';

    -- 06
    T6 <= '1' when (dezena = "0000" and unidade = "0110")
          else '0';

    -- 20
    T20 <= '1' when (dezena = "0010" and unidade = "0000")
           else '0';

    -- 60
    T60 <= '1' when (dezena = "0110" and unidade = "0000")
           else '0';

end Behavioral;
