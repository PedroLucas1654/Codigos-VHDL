
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_mux8_1 is
end tb_mux8_1;

architecture Behavioral of tb_mux8_1 is

    component mux8_1
        Port (
            S : in  STD_LOGIC_VECTOR (2 downto 0);
            D : in  STD_LOGIC_VECTOR (7 downto 0);
            Y : out STD_LOGIC
        );
    end component;

    signal S_tb : STD_LOGIC_VECTOR (2 downto 0);
    signal D_tb : STD_LOGIC_VECTOR (7 downto 0);
    signal Y_tb : STD_LOGIC;

begin

    uut: mux8_1
        port map (
            S => S_tb,
            D => D_tb,
            Y => Y_tb
        );

    process
    begin
       
        D_tb <= "10101010";

        S_tb <= "000"; wait for 10 ns;
        S_tb <= "001"; wait for 10 ns;
        S_tb <= "010"; wait for 10 ns;
        S_tb <= "011"; wait for 10 ns;
        S_tb <= "100"; wait for 10 ns;
        S_tb <= "101"; wait for 10 ns;
        S_tb <= "110"; wait for 10 ns;
        S_tb <= "111"; wait for 10 ns;

        wait;
    end process;

end Behavioral;
