library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity contador100 is
    Port (
        clock  : in  STD_LOGIC;
        reset  : in  STD_LOGIC;
        enable : in  STD_LOGIC;
        load   : in  STD_LOGIC;

        Ddez   : in  STD_LOGIC_VECTOR(3 downto 0);
        Duni   : in  STD_LOGIC_VECTOR(3 downto 0);

        Qdez   : out STD_LOGIC_VECTOR(3 downto 0);
        Quni   : out STD_LOGIC_VECTOR(3 downto 0)
    );
end contador100;

architecture Structural of contador100 is

    component contador10
        Port (
            clock  : in  STD_LOGIC;
            reset  : in  STD_LOGIC;
            enable : in  STD_LOGIC;
            rci    : in  STD_LOGIC;
            load   : in  STD_LOGIC;
            D      : in  STD_LOGIC_VECTOR(3 downto 0);

            Q       : out STD_LOGIC_VECTOR(3 downto 0);
            rco     : out STD_LOGIC
        );
    end component;

    signal rco_unidade : STD_LOGIC;

begin

    ---------------------------------------------------------
    -- Contador das unidades
    ---------------------------------------------------------

    UNIDADES : contador10
    port map(

        clock  => clock,
        reset  => reset,
        enable => enable,
        rci    => '0',
        load   => load,
        D       => Duni,

        Q       => Quni,
        rco     => rco_unidade

    );

    ---------------------------------------------------------
    -- Contador das dezenas
    ---------------------------------------------------------

    DEZENAS : contador10
    port map(

        clock  => clock,
        reset  => reset,
        enable => enable,
        rci    => rco_unidade,
        load   => load,
        D       => Ddez,

        Q       => Qdez,
        rco     => open

    );

end Structural;

