entity testbench_multiplexador is
end;

library ieee;
use ieee.std_logic_1164.all;

architecture tb_multiplexador of testbench_multiplexador is

component multiplexador
port(
    S : in  std_logic_vector(1 downto 0);
    D : in  std_logic_vector(3 downto 0);
    Y : out std_logic
);
end component;

signal S_1 : std_logic_vector(1 downto 0);
signal D_1 : std_logic_vector(3 downto 0);

signal S0, S1 : std_logic;
signal D0, D1, D2, D3 : std_logic;

begin

S_1(0) <= S0;
S_1(1) <= S1;

D_1(0) <= D0;
D_1(1) <= D1;
D_1(2) <= D2;
D_1(3) <= D3;

mux1: multiplexador 
port map (
    S => S_1,
    D => D_1,
    Y => open
);

estimulo : process
begin

    D0<='1'; D1<='0'; D2<='0'; D3<='0'; S1<='0'; S0<='0'; wait for 5 ns;
    D0<='0'; D1<='1'; D2<='0'; D3<='0'; S1<='0'; S0<='1'; wait for 5 ns;
    D0<='0'; D1<='0'; D2<='1'; D3<='0'; S1<='1'; S0<='0'; wait for 5 ns;
    D0<='0'; D1<='0'; D2<='0'; D3<='1'; S1<='1'; S0<='1'; wait for 5 ns;

    wait;
end process;

end tb_multiplexador;
