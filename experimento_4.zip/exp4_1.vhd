architecture Structural of q1 is

    component Multiplexador
        Port (
            S : in STD_LOGIC_VECTOR(1 downto 0);
            D : in STD_LOGIC_VECTOR(3 downto 0);
            Y : out STD_LOGIC
        );
    end component;

    signal S_sel : STD_LOGIC_VECTOR(1 downto 0);
    signal D_X, D_Y : STD_LOGIC_VECTOR(3 downto 0);

begin

    S_sel <= B & C;

    -- Montagem dos vetores (AGORA OK)
    D_X <= '0' & A & A & '1';
    D_Y <= '0' & '0' & '1' & A;

    mux_X: Multiplexador port map(
        S => S_sel,
        D => D_X,
        Y => X
    );

    mux_Y: Multiplexador port map(
        S => S_sel,
        D => D_Y,
        Y => Y
    );

end Structural;
