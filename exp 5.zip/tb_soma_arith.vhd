library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_somador4_plus is
end tb_somador4_plus;

architecture Behavioral of tb_somador4_plus is

    ------------------------------------------------------------------
    -- COMPONENTE
    ------------------------------------------------------------------
    component somador4_plus
        Port (
            A : in  STD_LOGIC_VECTOR(3 downto 0);
            B : in  STD_LOGIC_VECTOR(3 downto 0);
            S : out STD_LOGIC_VECTOR(4 downto 0)
        );
    end component;

    ------------------------------------------------------------------
    -- SINAIS
    ------------------------------------------------------------------
    signal A_tb : STD_LOGIC_VECTOR(3 downto 0) := "0000";
    signal B_tb : STD_LOGIC_VECTOR(3 downto 0) := "0000";

    signal S_tb : STD_LOGIC_VECTOR(4 downto 0);

begin

    ------------------------------------------------------------------
    -- INST�NCIA
    ------------------------------------------------------------------
    uut: somador4_plus
        port map(
            A => A_tb,
            B => B_tb,
            S => S_tb
        );

    ------------------------------------------------------------------
    -- TESTES
    ------------------------------------------------------------------
    process
    begin

        for i in 0 to 15 loop

            for j in 0 to 15 loop

                A_tb <= std_logic_vector(to_unsigned(i,4));
                B_tb <= std_logic_vector(to_unsigned(j,4));

                wait for 20 ns;

            end loop;

        end loop;

        wait;

    end process;

end Behavioral;
