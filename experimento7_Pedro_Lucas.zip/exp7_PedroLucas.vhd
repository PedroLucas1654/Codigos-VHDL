library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity maq_refrigerante is
    Port (
        clk     : in STD_LOGIC;
        reset   : in STD_LOGIC;
        A       : in STD_LOGIC_VECTOR(1 downto 0);
        refri   : out STD_LOGIC;
        troco25 : out STD_LOGIC;
        troco50 : out STD_LOGIC
    );
end maq_refrigerante;

architecture Behavioral of maq_refrigerante is

    type estado_tipo is (
        S0, S25, S50, S75,
        VEND, T25,
        C25, C50, C75
    );

    signal estado : estado_tipo := S0;

begin

process(clk, reset)
begin
    if reset = '1' then
        estado <= S0;

    elsif rising_edge(clk) then

        case estado is

            when S0 =>
                case A is
                    when "01" => estado <= S25;
                    when "10" => estado <= S50;
                    when others => estado <= S0;
                end case;

            when S25 =>
                case A is
                    when "01" => estado <= S50;
                    when "10" => estado <= S75;
                    when "11" => estado <= C25;
                    when others => estado <= S25;
                end case;

            when S50 =>
                case A is
                    when "01" => estado <= S75;
                    when "10" => estado <= VEND;
                    when "11" => estado <= C50;
                    when others => estado <= S50;
                end case;

            when S75 =>
                case A is
                    when "01" => estado <= VEND;
                    when "10" => estado <= T25;
                    when "11" => estado <= C75;
                    when others => estado <= S75;
                end case;

            when VEND | T25 | C25 | C50 | C75 =>
                case A is
                    when "01" => estado <= S25;
                    when "10" => estado <= S50;
                    when others => estado <= S0;
                end case;

        end case;
    end if;
end process;

refri <= '1' when (estado = VEND or estado = T25) else '0';

troco25 <= '1' when (estado = T25 or estado = C25 or estado = C75) else '0';

troco50 <= '1' when (estado = C50 or estado = C75) else '0';

end Behavioral;
