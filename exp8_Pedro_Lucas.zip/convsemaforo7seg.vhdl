library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity convsemaforo7seg is
    port(
        RYGsemaforo : in  STD_LOGIC_VECTOR(2 downto 0);
        num7seg     : out STD_LOGIC_VECTOR(7 downto 0)
    );
end convsemaforo7seg;

architecture convsemaforo7seg_arch of convsemaforo7seg is

begin

    process(RYGsemaforo)
    begin

        case RYGsemaforo is

            ------------------------------------------------
            -- Verde (G)
            ------------------------------------------------

            when "001" =>
                -- gfedcba + dp
                num7seg <= "11000010";

            ------------------------------------------------
            -- Amarelo (Y)
            ------------------------------------------------

            when "010" =>
                num7seg <= "10010001";

            ------------------------------------------------
            -- Vermelho (R)
            ------------------------------------------------

            when "100" =>
                num7seg <= "11111010";

            ------------------------------------------------
            -- Display apagado
            ------------------------------------------------

            when others =>
                num7seg <= "11111111";

        end case;

    end process;

end convsemaforo7seg_arch;
