library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_q1 is
end tb_q1;

architecture Behavioral of tb_q1 is

    component q1
        Port (
            A, B, C : in STD_LOGIC;
            X, Y    : out STD_LOGIC
        );
    end component;

    signal A_tb, B_tb, C_tb : STD_LOGIC;
    signal X_tb, Y_tb       : STD_LOGIC;

begin

    uut: q1
        port map (
            A => A_tb,
            B => B_tb,
            C => C_tb,
            X => X_tb,
            Y => Y_tb
        );

    process
    begin
        -- Testando todas as combina��es (3 bits ? 8 casos)

        A_tb <= '0'; B_tb <= '0'; C_tb <= '0'; wait for 10 ns;
        A_tb <= '0'; B_tb <= '0'; C_tb <= '1'; wait for 10 ns;
        A_tb <= '0'; B_tb <= '1'; C_tb <= '0'; wait for 10 ns;
        A_tb <= '0'; B_tb <= '1'; C_tb <= '1'; wait for 10 ns;
        A_tb <= '1'; B_tb <= '0'; C_tb <= '0'; wait for 10 ns;
        A_tb <= '1'; B_tb <= '0'; C_tb <= '1'; wait for 10 ns;
        A_tb <= '1'; B_tb <= '1'; C_tb <= '0'; wait for 10 ns;
        A_tb <= '1'; B_tb <= '1'; C_tb <= '1'; wait for 10 ns;

        wait; -- finaliza simula��o
    end process;

end Behavioral;
