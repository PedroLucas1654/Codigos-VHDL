library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity jk_ff is
    Port (
        PR  : in  STD_LOGIC;
        CLR : in  STD_LOGIC;
        CLK : in  STD_LOGIC;
        J   : in  STD_LOGIC;
        K   : in  STD_LOGIC;
        Q   : out STD_LOGIC
    );
end jk_ff;

architecture Behavioral of jk_ff is

    signal Q_int : STD_LOGIC := '0';

begin

    process(PR, CLR, CLK)
    begin

        if (PR = '1') then

            Q_int <= '1';

        elsif (CLR = '1') then

            Q_int <= '0';

        elsif rising_edge(CLK) then

            case STD_LOGIC_VECTOR'(J & K) is

                when "00" =>
                    Q_int <= Q_int;

                when "01" =>
                    Q_int <= '0';

                when "10" =>
                    Q_int <= '1';

                when "11" =>
                    Q_int <= not Q_int;

                when others =>
                    null;

            end case;

        end if;

    end process;

    Q <= Q_int;

end Behavioral;
