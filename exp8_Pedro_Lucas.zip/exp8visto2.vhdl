library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity exp8visto2 is
    Port (
        clock   : in  STD_LOGIC;
        reset   : in  STD_LOGIC;
        enable  : in  STD_LOGIC;
        load    : in  STD_LOGIC;

        dezload : in  STD_LOGIC_VECTOR(3 downto 0);
        uniload : in  STD_LOGIC_VECTOR(3 downto 0);

        dezena  : out STD_LOGIC_VECTOR(3 downto 0);
        unidade : out STD_LOGIC_VECTOR(3 downto 0);

        T5  : out STD_LOGIC;
        T6  : out STD_LOGIC;
        T20 : out STD_LOGIC;
        T60 : out STD_LOGIC
    );
end exp8visto2;

architecture Structural of exp8visto2 is

    component contador100
        Port (
            clock  : in  STD_LOGIC;
            reset  : in  STD_LOGIC;
            enable : in  STD_LOGIC;
            load   : in  STD_LOGIC;

            Ddez   : in  STD_LOGIC_VECTOR(3 downto 0);
            Duni   : in  STD_LOGIC_VECTOR(3 downto 0);

            Qdez   : out STD_LOGIC_VECTOR(3 downto 0);
            Quni   : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

    component timeflags
        Port (
            dezena  : in  STD_LOGIC_VECTOR(3 downto 0);
            unidade : in  STD_LOGIC_VECTOR(3 downto 0);

            T5  : out STD_LOGIC;
            T6  : out STD_LOGIC;
            T20 : out STD_LOGIC;
            T60 : out STD_LOGIC
        );
    end component;

    signal dez_int : STD_LOGIC_VECTOR(3 downto 0);
    signal uni_int : STD_LOGIC_VECTOR(3 downto 0);

begin

    CONTADOR : contador100
    port map(
        clock  => clock,
        reset  => reset,
        enable => enable,
        load   => load,

        Ddez   => dezload,
        Duni   => uniload,

        Qdez   => dez_int,
        Quni   => uni_int
    );

    FLAGS : timeflags
    port map(
        dezena  => dez_int,
        unidade => uni_int,

        T5  => T5,
        T6  => T6,
        T20 => T20,
        T60 => T60
    );

    dezena  <= dez_int;
    unidade <= uni_int;

end Structural;
