library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_exp8visto2 is
end tb_exp8visto2;

architecture Behavioral of tb_exp8visto2 is

    component exp8visto2
        Port (
            clock   : in  STD_LOGIC;
            reset   : in  STD_LOGIC;
            enable  : in  STD_LOGIC;
            load    : in  STD_LOGIC;

            dezload : in  STD_LOGIC_VECTOR(3 downto 0);
            uniload : in  STD_LOGIC_VECTOR(3 downto 0);

            dezena  : out STD_LOGIC_VECTOR(3 downto 0);
            unidade : out STD_LOGIC_VECTOR(3 downto 0);

            T5  : out STD_LOGIC;
            T6  : out STD_LOGIC;
            T20 : out STD_LOGIC;
            T60 : out STD_LOGIC
        );
    end component;

    signal clock   : STD_LOGIC := '0';
    signal reset   : STD_LOGIC := '0';
    signal enable  : STD_LOGIC := '0';
    signal load    : STD_LOGIC := '0';

    signal dezload : STD_LOGIC_VECTOR(3 downto 0) := "0000";
    signal uniload : STD_LOGIC_VECTOR(3 downto 0) := "0000";

    signal dezena  : STD_LOGIC_VECTOR(3 downto 0);
    signal unidade : STD_LOGIC_VECTOR(3 downto 0);

    signal T5  : STD_LOGIC;
    signal T6  : STD_LOGIC;
    signal T20 : STD_LOGIC;
    signal T60 : STD_LOGIC;

begin

    DUT : exp8visto2
    port map(
        clock   => clock,
        reset   => reset,
        enable  => enable,
        load    => load,
        dezload => dezload,
        uniload => uniload,
        dezena  => dezena,
        unidade => unidade,
        T5      => T5,
        T6      => T6,
        T20     => T20,
        T60     => T60
    );

    --------------------------------------------------
    -- Clock de 20 ns
    --------------------------------------------------

    clk_process : process
    begin
        while true loop
            clock <= '0';
            wait for 10 ns;
            clock <= '1';
            wait for 10 ns;
        end loop;
    end process;

    --------------------------------------------------
    -- Est�mulos
    --------------------------------------------------

    stim_proc : process
    begin

        -- Inicializa��o

        dezload <= "0000";
        uniload <= "0000";
        enable  <= '0';
        load    <= '0';
        reset   <= '1';

        wait for 20 ns;

        reset <= '0';

        --------------------------------------------------
        -- Carrega 00
        --------------------------------------------------

        load <= '1';
        wait for 20 ns;
        load <= '0';

        --------------------------------------------------
        -- Conta normalmente
        --------------------------------------------------

        wait for 1400 ns;

        --------------------------------------------------
        -- Carrega 04
        --------------------------------------------------

        enable <= '1';

        dezload <= "0000";
        uniload <= "0100";

        load <= '1';
        wait for 20 ns;
        load <= '0';

        enable <= '0';

        wait for 60 ns;

        --------------------------------------------------
        -- Carrega 19
        --------------------------------------------------

        enable <= '1';

        dezload <= "0001";
        uniload <= "1001";

        load <= '1';
        wait for 20 ns;
        load <= '0';

        enable <= '0';

        wait for 60 ns;

        wait;

    end process;

end Behavioral;