entity testbench1 is 
end;

library ieee;
use ieee.std_logic_1164.all;

architecture tb_somador of testbench1 is

component somador
port(
    A    : in std_logic;
    B    : in std_logic;
    Cin  : in std_logic;	
    S    : out std_logic;
    Cout : out std_logic
);
end component;

signal A_1   : std_logic;
signal B_1   : std_logic;
signal Cin_1 : std_logic;

begin

somador1: somador 
port map (
    A => A_1,
    B => B_1,
    Cin => Cin_1,
    S => open,
    Cout => open
);

estimulo : process
begin
    A_1 <= '0'; B_1 <= '0'; Cin_1 <= '0'; wait for 5 ns;
    A_1 <= '0'; B_1 <= '0'; Cin_1 <= '1'; wait for 5 ns;
    A_1 <= '0'; B_1 <= '1'; Cin_1 <= '0'; wait for 5 ns;
    A_1 <= '0'; B_1 <= '1'; Cin_1 <= '1'; wait for 5 ns;
    A_1 <= '1'; B_1 <= '0'; Cin_1 <= '0'; wait for 5 ns;
    A_1 <= '1'; B_1 <= '0'; Cin_1 <= '1'; wait for 5 ns;
    A_1 <= '1'; B_1 <= '1'; Cin_1 <= '0'; wait for 5 ns;
    A_1 <= '1'; B_1 <= '1'; Cin_1 <= '1'; wait for 5 ns;

    wait;
end process;

end tb_somador;
