library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_somador4_component is
end tb_somador4_component;

architecture Behavioral of tb_somador4_component is


    component somador4_component
        Port (
            A : in  STD_LOGIC_VECTOR(3 downto 0);
            B : in  STD_LOGIC_VECTOR(3 downto 0);
            S : out STD_LOGIC_VECTOR(4 downto 0)
        );
    end component;

    signal A_tb : STD_LOGIC_VECTOR(3 downto 0) := "0000";
    signal B_tb : STD_LOGIC_VECTOR(3 downto 0) := "0000";

    signal S_tb : STD_LOGIC_VECTOR(4 downto 0);

begin


    uut: somador4_component
        port map(
            A => A_tb,
            B => B_tb,
            S => S_tb
        );


    process
    begin


        for i in 0 to 15 loop

            for j in 0 to 15 loop

                A_tb <= std_logic_vector(to_unsigned(i,4));
                B_tb <= std_logic_vector(to_unsigned(j,4));

                wait for 20 ns;

            end loop;

        end loop;

        wait;

    end process;

end Behavioral;
