library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_registrador_bidirecional is
end tb_registrador_bidirecional;

architecture Behavioral of tb_registrador_bidirecional is

    
    component registrador_bidirecional
        Port (
            CLK  : in  STD_LOGIC;
            RST  : in  STD_LOGIC;
            LOAD : in  STD_LOGIC;
            D    : in  STD_LOGIC_VECTOR(3 downto 0);
            DIR  : in  STD_LOGIC;
            L    : in  STD_LOGIC;
            R    : in  STD_LOGIC;
            Q    : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

   
    signal CLK_tb  : STD_LOGIC := '0';
    signal RST_tb  : STD_LOGIC := '0';
    signal LOAD_tb : STD_LOGIC := '0';

    signal D_tb    : STD_LOGIC_VECTOR(3 downto 0) := "0000";

    signal DIR_tb  : STD_LOGIC := '0';

    signal L_tb    : STD_LOGIC := '0';
    signal R_tb    : STD_LOGIC := '0';

    signal Q_tb    : STD_LOGIC_VECTOR(3 downto 0);

begin

   
    uut: registrador_bidirecional
        port map(
            CLK  => CLK_tb,
            RST  => RST_tb,
            LOAD => LOAD_tb,
            D    => D_tb,
            DIR  => DIR_tb,
            L    => L_tb,
            R    => R_tb,
            Q    => Q_tb
        );


    process
    begin

        while true loop

            CLK_tb <= '0';
            wait for 10 ns;

            CLK_tb <= '1';
            wait for 10 ns;

        end loop;

    end process;


    process
    begin


        RST_tb <= '1';
        wait for 20 ns;

        RST_tb <= '0';

        LOAD_tb <= '1';
        D_tb <= "1010";
        wait for 20 ns;

        LOAD_tb <= '0';

     
        DIR_tb <= '0';
        L_tb <= '1';
        wait for 80 ns;

        DIR_tb <= '1';
        R_tb <= '0';
        wait for 80 ns;

        wait;

    end process;

end Behavioral;
