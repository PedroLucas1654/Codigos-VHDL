library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity maqestados is
    Port (
        clock         : in STD_LOGIC;
        ligadesliga   : in STD_LOGIC;
        sensorA       : in STD_LOGIC;
        sensorB       : in STD_LOGIC;
        T5            : in STD_LOGIC;
        T6            : in STD_LOGIC;
        T20           : in STD_LOGIC;
        T60           : in STD_LOGIC;

        resetcounter  : out STD_LOGIC;

        semaforoA     : out STD_LOGIC_VECTOR(2 downto 0);
        semaforoB     : out STD_LOGIC_VECTOR(2 downto 0)
    );
end maqestados;

architecture maqestados_arch of maqestados is

    type estado_tipo is (

        A_VERDE,
        A_AMARELO,
        VERMELHO_AB,

        B_VERDE,
        B_AMARELO,
        VERMELHO_BA,

        INTERMITENTE_ON,
        INTERMITENTE_OFF

    );

    signal currentState : estado_tipo := A_VERDE;
    signal nextState    : estado_tipo := A_VERDE;

begin

-------------------------------------------------------
-- Registrador de estados
-------------------------------------------------------

process(clock)
begin

    if rising_edge(clock) then

        currentState <= nextState;

    end if;

end process;

-------------------------------------------------------
-- L�gica do pr�ximo estado
-------------------------------------------------------

process(currentState,
        ligadesliga,
        sensorA,
        sensorB,
        T5,
        T6,
        T20,
        T60)

begin

    nextState <= currentState;

    resetcounter <= '0';

    case currentState is

-------------------------------------------------------
-- VIA A LIBERADA
-------------------------------------------------------

        when A_VERDE =>

            if ligadesliga='0' then

                nextState <= INTERMITENTE_ON;
                resetcounter <= '1';

            elsif T60='1' then

                nextState <= A_AMARELO;
                resetcounter <= '1';

            elsif (T20='1' and sensorB='1' and sensorA='0') then

                nextState <= A_AMARELO;
                resetcounter <= '1';

            end if;

-------------------------------------------------------
-- VIA A AMARELA
-------------------------------------------------------

        when A_AMARELO =>

            if ligadesliga='0' then

                nextState <= INTERMITENTE_ON;
                resetcounter <= '1';

            elsif T6='1' then

                nextState <= VERMELHO_AB;
                resetcounter <= '1';

            end if;

-------------------------------------------------------
-- AMBOS VERMELHOS
-------------------------------------------------------

        when VERMELHO_AB =>

            if ligadesliga='0' then

                nextState <= INTERMITENTE_ON;
                resetcounter <= '1';

            elsif T5='1' then

                nextState <= B_VERDE;
                resetcounter <= '1';

            end if;


-------------------------------------------------------
-- VIA B LIBERADA
-------------------------------------------------------

        when B_VERDE =>

            if ligadesliga = '0' then

                nextState <= INTERMITENTE_ON;
                resetcounter <= '1';

            elsif T60 = '1' then

                nextState <= B_AMARELO;
                resetcounter <= '1';

            elsif (T20 = '1' and sensorA = '1' and sensorB = '0') then

                nextState <= B_AMARELO;
                resetcounter <= '1';

            end if;

-------------------------------------------------------
-- VIA B AMARELA
-------------------------------------------------------

        when B_AMARELO =>

            if ligadesliga = '0' then

                nextState <= INTERMITENTE_ON;
                resetcounter <= '1';

            elsif T6 = '1' then

                nextState <= VERMELHO_BA;
                resetcounter <= '1';

            end if;

-------------------------------------------------------
-- AMBOS VERMELHOS (ANTES DE LIBERAR A)
-------------------------------------------------------

        when VERMELHO_BA =>

            if ligadesliga = '0' then

                nextState <= INTERMITENTE_ON;
                resetcounter <= '1';

            elsif T5 = '1' then

                nextState <= A_VERDE;
                resetcounter <= '1';

            end if;

-------------------------------------------------------
-- MODO INTERMITENTE (AMARELO ACESO)
-------------------------------------------------------

        when INTERMITENTE_ON =>

            if ligadesliga = '1' then

                nextState <= A_VERDE;
                resetcounter <= '1';

            elsif T5 = '1' then

                nextState <= INTERMITENTE_OFF;
                resetcounter <= '1';

            end if;

-------------------------------------------------------
-- MODO INTERMITENTE (APAGADO)
-------------------------------------------------------

        when INTERMITENTE_OFF =>

            if ligadesliga = '1' then

                nextState <= A_VERDE;
                resetcounter <= '1';

            elsif T5 = '1' then

                nextState <= INTERMITENTE_ON;
                resetcounter <= '1';

            end if;

    end case;

end process;

-------------------------------------------------------
-- SA�DAS (MOORE)
-------------------------------------------------------

process(currentState)
begin

    case currentState is

        ------------------------------------------------
        -- Via A verde
        ------------------------------------------------
        when A_VERDE =>

            semaforoA <= "001"; -- Verde
            semaforoB <= "100"; -- Vermelho

        ------------------------------------------------
        -- Via A amarela
        ------------------------------------------------
        when A_AMARELO =>

            semaforoA <= "010"; -- Amarelo
            semaforoB <= "100"; -- Vermelho

        ------------------------------------------------
        -- Ambos vermelhos
        ------------------------------------------------
        when VERMELHO_AB =>

            semaforoA <= "100"; -- Vermelho
            semaforoB <= "100"; -- Vermelho

        ------------------------------------------------
        -- Via B verde
        ------------------------------------------------
        when B_VERDE =>

            semaforoA <= "100"; -- Vermelho
            semaforoB <= "001"; -- Verde

        ------------------------------------------------
        -- Via B amarela
        ------------------------------------------------
        when B_AMARELO =>

            semaforoA <= "100"; -- Vermelho
            semaforoB <= "010"; -- Amarelo

        ------------------------------------------------
        -- Ambos vermelhos
        ------------------------------------------------
        when VERMELHO_BA =>

            semaforoA <= "100"; -- Vermelho
            semaforoB <= "100"; -- Vermelho

        ------------------------------------------------
        -- Intermitente amarelo
        ------------------------------------------------
        when INTERMITENTE_ON =>

            semaforoA <= "010"; -- Amarelo
            semaforoB <= "010"; -- Amarelo

        ------------------------------------------------
        -- Intermitente apagado
        ------------------------------------------------
        when INTERMITENTE_OFF =>

            semaforoA <= "000";
            semaforoB <= "000";

    end case;

end process;

end maqestados_arch;