library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_comparacao is
end tb_comparacao;

architecture Behavioral of tb_comparacao is

    ------------------------------------------------------------------
    -- COMPONENTE QUEST�O 1
    ------------------------------------------------------------------
    component somador4_component
        Port (
            A : in  STD_LOGIC_VECTOR(3 downto 0);
            B : in  STD_LOGIC_VECTOR(3 downto 0);
            S : out STD_LOGIC_VECTOR(4 downto 0)
        );
    end component;

    ------------------------------------------------------------------
    -- COMPONENTE QUEST�O 2
    ------------------------------------------------------------------
    component somador4_plus
        Port (
            A : in  STD_LOGIC_VECTOR(3 downto 0);
            B : in  STD_LOGIC_VECTOR(3 downto 0);
            S : out STD_LOGIC_VECTOR(4 downto 0)
        );
    end component;

    ------------------------------------------------------------------
    -- SINAIS DE ENTRADA
    ------------------------------------------------------------------
    signal A_tb : STD_LOGIC_VECTOR(3 downto 0) := "0000";
    signal B_tb : STD_LOGIC_VECTOR(3 downto 0) := "0000";

    ------------------------------------------------------------------
    -- SA�DAS DOS SOMADORES
    ------------------------------------------------------------------
    signal S1_tb : STD_LOGIC_VECTOR(4 downto 0);
    signal S2_tb : STD_LOGIC_VECTOR(4 downto 0);

    ------------------------------------------------------------------
    -- SINAL DE COMPARA��O
    ------------------------------------------------------------------
    signal ERRO : STD_LOGIC_VECTOR(4 downto 0);

begin

    ------------------------------------------------------------------
    -- DUT 1
    ------------------------------------------------------------------
    DUT1: somador4_component
        port map(
            A => A_tb,
            B => B_tb,
            S => S1_tb
        );

    ------------------------------------------------------------------
    -- DUT 2
    ------------------------------------------------------------------
    DUT2: somador4_plus
        port map(
            A => A_tb,
            B => B_tb,
            S => S2_tb
        );

    ------------------------------------------------------------------
    -- COMPARA��O XOR
    ------------------------------------------------------------------
    ERRO <= S1_tb xor S2_tb;

    ------------------------------------------------------------------
    -- PROCESSO DE TESTE
    ------------------------------------------------------------------
    process
    begin

        --------------------------------------------------------------
        -- TESTA TODAS AS COMBINA��ES
        --------------------------------------------------------------
        for i in 0 to 15 loop

            for j in 0 to 15 loop

                A_tb <= std_logic_vector(to_unsigned(i,4));
                B_tb <= std_logic_vector(to_unsigned(j,4));

                wait for 20 ns;

            end loop;

        end loop;

        wait;

    end process;

end Behavioral;
