library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_exp8visto1 is
end tb_exp8visto1;

architecture Behavioral of tb_exp8visto1 is

    component exp8visto1
        port(
            clock   : in STD_LOGIC;
            reset   : in STD_LOGIC;
            enable  : in STD_LOGIC;
            load    : in STD_LOGIC;
            dezload : in STD_LOGIC_VECTOR(3 downto 0);
            uniload : in STD_LOGIC_VECTOR(3 downto 0);
            dezena  : out STD_LOGIC_VECTOR(3 downto 0);
            unidade : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

    signal clock   : STD_LOGIC := '0';
    signal reset   : STD_LOGIC := '0';
    signal enable  : STD_LOGIC := '0';
    signal load    : STD_LOGIC := '0';

    signal dezload : STD_LOGIC_VECTOR(3 downto 0) := "0000";
    signal uniload : STD_LOGIC_VECTOR(3 downto 0) := "0000";

    signal dezena  : STD_LOGIC_VECTOR(3 downto 0);
    signal unidade : STD_LOGIC_VECTOR(3 downto 0);

begin

    DUT : exp8visto1
    port map(
        clock   => clock,
        reset   => reset,
        enable  => enable,
        load    => load,
        dezload => dezload,
        uniload => uniload,
        dezena  => dezena,
        unidade => unidade
    );

    ------------------------------------------------------------------
    -- Clock de 20 ns
    ------------------------------------------------------------------

    clk_process : process
    begin
        while true loop
            clock <= '0';
            wait for 10 ns;
            clock <= '1';
            wait for 10 ns;
        end loop;
    end process;

    ------------------------------------------------------------------
    -- Est�mulos
    ------------------------------------------------------------------

    stim_proc : process
    begin

        ------------------------------------------------------
        -- Reset
        ------------------------------------------------------

        reset <= '1';
        wait for 20 ns;

        reset <= '0';
        wait for 20 ns;

        ------------------------------------------------------
        -- Load = 37
        ------------------------------------------------------

        dezload <= "0011";
        uniload <= "0111";
        load <= '1';

        wait for 20 ns;

        load <= '0';

        ------------------------------------------------------
        -- Conta durante 20 clocks
        ------------------------------------------------------

        wait for 400 ns;

        ------------------------------------------------------
        -- Pausa contagem
        ------------------------------------------------------

        enable <= '1';

        wait for 100 ns;

        ------------------------------------------------------
        -- Continua contagem
        ------------------------------------------------------

        enable <= '0';

        wait for 200 ns;

        ------------------------------------------------------
        -- Novo reset
        ------------------------------------------------------

        reset <= '1';

        wait for 20 ns;

        reset <= '0';

        wait for 100 ns;

        wait;

    end process;

end Behavioral;
