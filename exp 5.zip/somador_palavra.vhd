library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity somador4_component is
    Port (
        A : in  STD_LOGIC_VECTOR(3 downto 0);
        B : in  STD_LOGIC_VECTOR(3 downto 0);
        S : out STD_LOGIC_VECTOR(4 downto 0)
    );
end somador4_component;

architecture Structural of somador4_component is

    component somador
        Port (
            A    : in  STD_LOGIC;
            B    : in  STD_LOGIC;
            Cin  : in  STD_LOGIC;
            S    : out STD_LOGIC;
            Cout : out STD_LOGIC
        );
    end component;


    signal C1, C2, C3, C4 : STD_LOGIC;

begin

 
    U0: somador
        port map(
            A    => A(0),
            B    => B(0),
            Cin  => '0',
            S    => S(0),
            Cout => C1
        );


    U1: somador
        port map(
            A    => A(1),
            B    => B(1),
            Cin  => C1,
            S    => S(1),
            Cout => C2
        );

  
    U2: somador
        port map(
            A    => A(2),
            B    => B(2),
            Cin  => C2,
            S    => S(2),
            Cout => C3
        );


    U3: somador
        port map(
            A    => A(3),
            B    => B(3),
            Cin  => C3,
            S    => S(3),
            Cout => C4
        );

    S(4) <= C4;

end Structural;
