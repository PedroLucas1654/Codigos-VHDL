library  IEEE;
use IEEE.std_logic_1164.all;







entity somador  is port (
A  : in std_logic;
B  : in  std_logic;
Cin  : in std_logic;
S  : out std_logic;
Cout  : out std_logic
);
end somador;

architecture Behavioral  of  somador  is

begin

S <= A xor B xor Cin;
Cout <= (A and B) or (A and Cin) or (B and Cin);

end Behavioral;
