library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_decoder is
end tb_decoder;

architecture Behavioral of tb_decoder is

    component decoder
        Port (
            A : in  STD_LOGIC_VECTOR (3 downto 0); 
            Y : out STD_LOGIC_VECTOR (15 downto 0)
        );
    end component;

    signal A_tb : STD_LOGIC_VECTOR (3 downto 0);
    signal Y_tb : STD_LOGIC_VECTOR (15 downto 0);

begin

    uut: decoder
        port map (
            A => A_tb,
            Y => Y_tb
        );

    process
    begin

        A_tb <= "0000"; wait for 10 ns;
        A_tb <= "0001"; wait for 10 ns;
        A_tb <= "0010"; wait for 10 ns;
        A_tb <= "0011"; wait for 10 ns;
        A_tb <= "0100"; wait for 10 ns;
        A_tb <= "0101"; wait for 10 ns;
        A_tb <= "0110"; wait for 10 ns;
        A_tb <= "0111"; wait for 10 ns;
        A_tb <= "1000"; wait for 10 ns;
        A_tb <= "1001"; wait for 10 ns;
        A_tb <= "1010"; wait for 10 ns;
        A_tb <= "1011"; wait for 10 ns;
        A_tb <= "1100"; wait for 10 ns;
        A_tb <= "1101"; wait for 10 ns;
        A_tb <= "1110"; wait for 10 ns;
        A_tb <= "1111"; wait for 10 ns;

        wait;
    end process;

end Behavioral;
