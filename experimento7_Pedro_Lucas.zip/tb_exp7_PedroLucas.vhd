library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_maq_refrigerante is
end tb_maq_refrigerante;

architecture behavior of tb_maq_refrigerante is

    component maq_refrigerante
        Port (
            clk     : in STD_LOGIC;
            reset   : in STD_LOGIC;
            A       : in STD_LOGIC_VECTOR(1 downto 0);
            refri   : out STD_LOGIC;
            troco25 : out STD_LOGIC;
            troco50 : out STD_LOGIC
        );
    end component;

    signal clk     : STD_LOGIC := '0';
    signal reset   : STD_LOGIC := '0';
    signal A       : STD_LOGIC_VECTOR(1 downto 0) := "00";

    signal refri   : STD_LOGIC;
    signal troco25 : STD_LOGIC;
    signal troco50 : STD_LOGIC;

begin

    uut: maq_refrigerante
        port map(
            clk     => clk,
            reset   => reset,
            A       => A,
            refri   => refri,
            troco25 => troco25,
            troco50 => troco50
        );

    -- Clock de 20 ns
    clk_process: process
    begin
        while true loop
            clk <= '0';
            wait for 10 ns;
            clk <= '1';
            wait for 10 ns;
        end loop;
    end process;

    stim_proc: process
    begin

        -- Reset inicial
        reset <= '1';
        wait for 20 ns;
        reset <= '0';

        ----------------------------------------------------------------
        -- TESTE 1: 25 + 25 + 25 + 25 = refri
        ----------------------------------------------------------------
        A <= "01"; wait for 20 ns;
        A <= "01"; wait for 20 ns;
        A <= "01"; wait for 20 ns;
        A <= "01"; wait for 20 ns;
        A <= "00"; wait for 20 ns;

        ----------------------------------------------------------------
        -- TESTE 2: 50 + 50 = refri
        ----------------------------------------------------------------
        A <= "10"; wait for 20 ns;
        A <= "10"; wait for 20 ns;
        A <= "00"; wait for 20 ns;

        ----------------------------------------------------------------
        -- TESTE 3: 50 + 25 + 25 = refri
        ----------------------------------------------------------------
        A <= "10"; wait for 20 ns;
        A <= "01"; wait for 20 ns;
        A <= "01"; wait for 20 ns;
        A <= "00"; wait for 20 ns;

        ----------------------------------------------------------------
        -- TESTE 4: 50 + 50 + 25
        ----------------------------------------------------------------
        A <= "10"; wait for 20 ns;
        A <= "10"; wait for 20 ns;
        A <= "01"; wait for 20 ns;
        A <= "00"; wait for 20 ns;

        ----------------------------------------------------------------
        -- TESTE 5: cancelamento em 25
        ----------------------------------------------------------------
        A <= "01"; wait for 20 ns;
        A <= "11"; wait for 20 ns;
        A <= "00"; wait for 20 ns;

        ----------------------------------------------------------------
        -- TESTE 6: cancelamento em 50
        ----------------------------------------------------------------
        A <= "10"; wait for 20 ns;
        A <= "11"; wait for 20 ns;
        A <= "00"; wait for 20 ns;

        ----------------------------------------------------------------
        -- TESTE 7: cancelamento em 75
        ----------------------------------------------------------------
        A <= "10"; wait for 20 ns;
        A <= "01"; wait for 20 ns;
        A <= "11"; wait for 20 ns;
        A <= "00"; wait for 20 ns;

        wait;

    end process;

end behavior;
