library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_jk_ff is
end tb_jk_ff;

architecture Behavioral of tb_jk_ff is

    component jk_ff
        Port (
            PR  : in  STD_LOGIC;
            CLR : in  STD_LOGIC;
            CLK : in  STD_LOGIC;
            J   : in  STD_LOGIC;
            K   : in  STD_LOGIC;
            Q   : out STD_LOGIC
        );
    end component;

    signal PR_tb  : STD_LOGIC := '0';
    signal CLR_tb : STD_LOGIC := '0';
    signal CLK_tb : STD_LOGIC := '0';
    signal J_tb   : STD_LOGIC := '0';
    signal K_tb   : STD_LOGIC := '0';

    signal Q_tb   : STD_LOGIC;

begin

    uut: jk_ff
        port map(
            PR  => PR_tb,
            CLR => CLR_tb,
            CLK => CLK_tb,
            J   => J_tb,
            K   => K_tb,
            Q   => Q_tb
        );

    process
    begin

        while true loop

            CLK_tb <= '0';
            wait for 10 ns;

            CLK_tb <= '1';
            wait for 10 ns;

        end loop;

    end process;

    process
    begin

        PR_tb <= '1';
        wait for 20 ns;

        PR_tb <= '0';

        CLR_tb <= '1';
        wait for 20 ns;

        CLR_tb <= '0';

        J_tb <= '0';
        K_tb <= '0';
        wait for 40 ns;

        J_tb <= '0';
        K_tb <= '1';
        wait for 40 ns;

        J_tb <= '1';
        K_tb <= '0';
        wait for 40 ns;

        J_tb <= '1';
        K_tb <= '1';
        wait for 80 ns;

        wait;

    end process;

end Behavioral;
