library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity registrador_bidirecional is
    Port (
        CLK  : in  STD_LOGIC;
        RST  : in  STD_LOGIC;
        LOAD : in  STD_LOGIC;
        D    : in  STD_LOGIC_VECTOR(3 downto 0);
        DIR  : in  STD_LOGIC;
        L    : in  STD_LOGIC;
        R    : in  STD_LOGIC;
        Q    : out STD_LOGIC_VECTOR(3 downto 0)
    );
end registrador_bidirecional;

architecture Behavioral of registrador_bidirecional is

    signal Q_int : STD_LOGIC_VECTOR(3 downto 0) := "0000";

begin

    process(CLK)
    begin

        if rising_edge(CLK) then

     
            if (RST = '1') then

                Q_int <= "0000";

            elsif (LOAD = '1') then

                Q_int <= D;

            elsif (DIR = '0') then

                Q_int <= Q_int(2 downto 0) & L;

            elsif (DIR = '1') then

                Q_int <= R & Q_int(3 downto 1);

            end if;

        end if;

    end process;

    Q <= Q_int;

end Behavioral;
