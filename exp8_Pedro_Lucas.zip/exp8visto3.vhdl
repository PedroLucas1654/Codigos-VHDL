library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity exp8visto3 is
    port(
        clock        : in  STD_LOGIC;
        ligadesliga  : in  STD_LOGIC;
        sensorA      : in  STD_LOGIC;
        sensorB      : in  STD_LOGIC;
        num7seg      : out STD_LOGIC_VECTOR(7 downto 0);
        displays     : out STD_LOGIC_VECTOR(3 downto 0)
    );
end exp8visto3;

architecture exp8visto3_arch of exp8visto3 is

    -----------------------------------------------------------------
    -- COMPONENTES
    -----------------------------------------------------------------

    component divclock
        port(
            clock50MHz : in STD_LOGIC;
            clock1Hz   : out STD_LOGIC
        );
    end component;

    component contador100
        port(
            clock  : in STD_LOGIC;
            reset  : in STD_LOGIC;
            enable : in STD_LOGIC;
            load   : in STD_LOGIC;
            Ddez   : in STD_LOGIC_VECTOR(3 downto 0);
            Duni   : in STD_LOGIC_VECTOR(3 downto 0);
            Qdez   : out STD_LOGIC_VECTOR(3 downto 0);
            Quni   : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

    component timeflags
        port(
            dezena  : in STD_LOGIC_VECTOR(3 downto 0);
            unidade : in STD_LOGIC_VECTOR(3 downto 0);
            T5  : out STD_LOGIC;
            T6  : out STD_LOGIC;
            T20 : out STD_LOGIC;
            T60 : out STD_LOGIC
        );
    end component;

    component maqestados
        port(
            clock        : in STD_LOGIC;
            ligadesliga  : in STD_LOGIC;
            sensorA      : in STD_LOGIC;
            sensorB      : in STD_LOGIC;
            T5           : in STD_LOGIC;
            T6           : in STD_LOGIC;
            T20          : in STD_LOGIC;
            T60          : in STD_LOGIC;
            resetcounter : out STD_LOGIC;
            semaforoA    : out STD_LOGIC_VECTOR(2 downto 0);
            semaforoB    : out STD_LOGIC_VECTOR(2 downto 0)
        );
    end component;

    component convbinario7seg
        port(
            numbinario : in STD_LOGIC_VECTOR(3 downto 0);
            num7seg    : out STD_LOGIC_VECTOR(7 downto 0)
        );
    end component;

    component convsemaforo7seg
        port(
            RYGsemaforo : in STD_LOGIC_VECTOR(2 downto 0);
            num7seg     : out STD_LOGIC_VECTOR(7 downto 0)
        );
    end component;

    component mostrador
        port(
            num7seg3 : in STD_LOGIC_VECTOR(7 downto 0);
            num7seg2 : in STD_LOGIC_VECTOR(7 downto 0);
            num7seg1 : in STD_LOGIC_VECTOR(7 downto 0);
            num7seg0 : in STD_LOGIC_VECTOR(7 downto 0);
            clock50Mhz : in STD_LOGIC;
            num7seg : out STD_LOGIC_VECTOR(7 downto 0);
            displays : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

    -----------------------------------------------------------------
    -- SINAIS
    -----------------------------------------------------------------

    signal clk1Hz : STD_LOGIC;

    signal dezena  : STD_LOGIC_VECTOR(3 downto 0);
    signal unidade : STD_LOGIC_VECTOR(3 downto 0);

    signal T5,T6,T20,T60 : STD_LOGIC;

    signal resetcounter : STD_LOGIC;

    signal semA : STD_LOGIC_VECTOR(2 downto 0);
    signal semB : STD_LOGIC_VECTOR(2 downto 0);

    signal disp3,disp2,disp1,disp0 : STD_LOGIC_VECTOR(7 downto 0);

begin

    -----------------------------------------------------------------
    -- Divisor de clock
    -----------------------------------------------------------------

    U1: divclock
    port map(
        clock50MHz => clock,
        clock1Hz   => clk1Hz
    );

    -----------------------------------------------------------------
    -- Contador
    -----------------------------------------------------------------

    U2: contador100
    port map(
        clock  => clk1Hz,
        reset  => resetcounter,
        enable => '1',
        load   => '0',
        Ddez   => "0000",
        Duni   => "0000",
        Qdez   => dezena,
        Quni   => unidade
    );

    -----------------------------------------------------------------
    -- Flags de tempo
    -----------------------------------------------------------------

    U3: timeflags
    port map(
        dezena  => dezena,
        unidade => unidade,
        T5      => T5,
        T6      => T6,
        T20     => T20,
        T60     => T60
    );

    -----------------------------------------------------------------
    -- M�quina de estados
    -----------------------------------------------------------------

    U4: maqestados
    port map(
        clock        => clk1Hz,
        ligadesliga  => ligadesliga,
        sensorA      => sensorA,
        sensorB      => sensorB,
        T5           => T5,
        T6           => T6,
        T20          => T20,
        T60          => T60,
        resetcounter => resetcounter,
        semaforoA    => semA,
        semaforoB    => semB
    );

    -----------------------------------------------------------------
    -- Conversores
    -----------------------------------------------------------------

    U5: convsemaforo7seg
    port map(
        RYGsemaforo => semA,
        num7seg     => disp3
    );

    U6: convbinario7seg
    port map(
        numbinario => dezena,
        num7seg    => disp2
    );

    U7: convbinario7seg
    port map(
        numbinario => unidade,
        num7seg    => disp1
    );

    U8: convsemaforo7seg
    port map(
        RYGsemaforo => semB,
        num7seg     => disp0
    );

    -----------------------------------------------------------------
    -- Multiplexador dos displays
    -----------------------------------------------------------------

    U9: mostrador
    port map(
        num7seg3   => disp3,
        num7seg2   => disp2,
        num7seg1   => disp1,
        num7seg0   => disp0,
        clock50Mhz => clock,
        num7seg    => num7seg,
        displays   => displays
    );

end exp8visto3_arch;


