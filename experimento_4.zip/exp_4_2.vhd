library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity q2 is
    Port (
        A, B, C, D, E, F, G : in STD_LOGIC;
        S : out STD_LOGIC
    );
end q2;

architecture Structural of q2 is

    -- Decoder 4x16
    component decoder
        Port (
            A : in  STD_LOGIC_VECTOR (3 downto 0);
            Y : out STD_LOGIC_VECTOR (15 downto 0)
        );
    end component;

    -- MUX 8x1
    component mux8_1
        Port (
            S : in  STD_LOGIC_VECTOR (2 downto 0);
            D : in  STD_LOGIC_VECTOR (7 downto 0);
            Y : out STD_LOGIC
        );
    end component;

    -- Sinais internos
    signal ABCD    : STD_LOGIC_VECTOR(3 downto 0);
    signal EFG     : STD_LOGIC_VECTOR(2 downto 0);
    signal dec_out : STD_LOGIC_VECTOR(15 downto 0);
    signal mux_in  : STD_LOGIC_VECTOR(7 downto 0);

begin

    -- Montagem dos vetores (ESSENCIAL pra n�o dar erro)
    ABCD <= A & B & C & D;
    EFG  <= E & F & G;

    -- Inst�ncia do decoder
    dec: decoder port map(
        A => ABCD,
        Y => dec_out
    );

    -- Inst�ncia do mux
    mux: mux8_1 port map(
        S => EFG,
        D => mux_in,
        Y => S
    );

    ------------------------------------------------------------------
    -- ?? MAPEAMENTO DOS MINTERMOS (EXEMPLO BASE)
    -- ?? Voc� pode precisar ajustar conforme a equa��o exata
    ------------------------------------------------------------------

    mux_in(0) <= dec_out(1) or dec_out(3);
    mux_in(1) <= dec_out(5);
    mux_in(2) <= dec_out(7);
    mux_in(3) <= dec_out(9);
    mux_in(4) <= dec_out(11);
    mux_in(5) <= dec_out(13);
    mux_in(6) <= dec_out(15);
    mux_in(7) <= '0';

end Structural;
