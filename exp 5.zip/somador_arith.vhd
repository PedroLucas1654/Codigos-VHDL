library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity somador4_plus is
    Port (
        A : in  STD_LOGIC_VECTOR(3 downto 0);
        B : in  STD_LOGIC_VECTOR(3 downto 0);
        S : out STD_LOGIC_VECTOR(4 downto 0)
    );
end somador4_plus;

architecture Behavioral of somador4_plus is
begin

    ------------------------------------------------------------------
    -- SOMA DOS VETORES
    ------------------------------------------------------------------
    S <= std_logic_vector(
            unsigned('0' & A) +
            unsigned('0' & B)
         );

end Behavioral;
