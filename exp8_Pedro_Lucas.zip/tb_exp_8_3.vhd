library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_exp8visto3 is
end tb_exp8visto3;

architecture behavior of tb_exp8visto3 is

    component exp8visto3
        port(
            clock        : in  STD_LOGIC;
            ligadesliga  : in  STD_LOGIC;
            sensorA      : in  STD_LOGIC;
            sensorB      : in  STD_LOGIC;
            num7seg      : out STD_LOGIC_VECTOR(7 downto 0);
            displays     : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;

    signal clock        : STD_LOGIC := '0';
    signal ligadesliga  : STD_LOGIC := '1';
    signal sensorA      : STD_LOGIC := '0';
    signal sensorB      : STD_LOGIC := '0';

    signal num7seg      : STD_LOGIC_VECTOR(7 downto 0);
    signal displays     : STD_LOGIC_VECTOR(3 downto 0);

begin

    DUT : exp8visto3
    port map(
        clock        => clock,
        ligadesliga  => ligadesliga,
        sensorA      => sensorA,
        sensorB      => sensorB,
        num7seg      => num7seg,
        displays     => displays
    );

    -------------------------------------------------
    -- Clock (20 ns)
    -------------------------------------------------

    clk_process : process
    begin
        while true loop
            clock <= '0';
            wait for 10 ns;

            clock <= '1';
            wait for 10 ns;
        end loop;
    end process;

    -------------------------------------------------
    -- Est�mulos
    -------------------------------------------------

    stim_proc : process
    begin

        -------------------------------------------------
        -- Sistema ligado sem carros
        -------------------------------------------------

        ligadesliga <= '1';
        sensorA <= '0';
        sensorB <= '0';

        wait for 300 ns;

        -------------------------------------------------
        -- Carro em B
        -------------------------------------------------

        sensorB <= '1';

        wait for 300 ns;

        -------------------------------------------------
        -- Carros nas duas vias
        -------------------------------------------------

        sensorA <= '1';
        sensorB <= '1';

        wait for 300 ns;

        -------------------------------------------------
        -- Apenas carro em A
        -------------------------------------------------

        sensorA <= '1';
        sensorB <= '0';

        wait for 300 ns;

        -------------------------------------------------
        -- Sistema desligado
        -------------------------------------------------

        ligadesliga <= '0';

        wait for 300 ns;

        -------------------------------------------------
        -- Liga novamente
        -------------------------------------------------

        ligadesliga <= '1';

        sensorA <= '0';
        sensorB <= '0';

        wait for 300 ns;

        wait;

    end process;

end behavior;